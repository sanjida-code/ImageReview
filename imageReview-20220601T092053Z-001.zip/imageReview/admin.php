<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <!-- bootstrap css link  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body>
<section class="h-100 gradient-form mt-5" style="background-color: #eee;">
  <div class="container py-5 h-100 mt-5">
    <div class=" d-flex justify-content-center align-items-center h-100">
      <div>
        <div class="card rounded-3 text-black">
          <div class="g-0">
            <div>
              <div class="card-body p-md-5 mx-md-4">

                <form action="admin_login_php.php" method="POST">
                  <h3>Admin login</h3>

                  <div class="form-outline my-4">
                    <label class="form-label" for="form2Example11">Username</label> 
                    <input type="text" id="form2Example11" name="name" class="form-control" placeholder="Enter Username"/>
                  </div>

                  <div class="form-outline mb-4">
                    <label class="form-label" for="form2Example22">Password</label>
                    <input type="password" id="psw" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="Enter Password" id="form3Example4c" class="form-control" required><br>
                    <input type="checkbox" onclick="myFunction()"style="text-align:right;">Show Password<br>
                  </div>

                  <div class="text-center pt-1 mb-5 pb-1">
                  <button class="btn btn-primary " type="submit" name="submit" id="myBtn"><b>Sign in</b></button>
                  </div>
                </form>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- password show  -->
<script>
function myFunction() {
  var x = document.getElementById("psw");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
<!-- Bootstrap js link -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>