<?php
include("header.php");
?>

<div class="container-fluid my-5 p-5">
<div class="my-5 p-5">
    <h1>Image Review Project</h1>
</div>
</div>

<?php
include("footer.php");
?>