<?php
$servername="localhost" ;
$serveruser="root" ;
$serverpass="" ;
$DBname="review" ;
$conn=mysqli_connect($servername , $serveruser , $serverpass , $DBname ) ;
?>